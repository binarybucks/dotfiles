#!/bin/bash


BASEDIR=$(readlink -f "$0")
echo $BASEDIR
BACKUPDIR="$BASEDIR/backup"

git pull
function doIt() { 
  # Prepare backup directory
  if [ -d "$BACKUPDIR" ]; then
    rm -rf $BACKUPDIR/*
  
  else
    mkdir $BACKUPDIR
  fi

  if [ -a ~/.zshrc ]; then
    mv ~/.zshrc $BACKUPDIR
  fi
  ln -f -s $BASEDIR/zsh/zshrc ~/.zshrc
  
  if [ -a ~/.bashrc ]; then
    mv ~/.bashrc $BACKUPDIR
  fi
  ln -f -s $BASEDIR/bash/bashrc ~/.bashrc

  if [ -a ~/.tmuxrc ]; then
    mv ~/.tmuxrc $BACKUPDIR
  fi
  ln -f -s $BASEDIR/tmux/tmuxrc ~/.tmuxrc

  if [ -a ~/.scripts ]; then
    mv ~/.scripts $BACKUPDIR
  fi
  ln -f -s $BASEDIR/scripts ~/.scripts
}


if [ "$1" == "--force" -o "$1" == "-f" ]; then
  doIt
else
  read -p "This may change existing files in your home directory. Are you sure? (y/n) " -n 1
  echo
  if [[ $REPLY =~ ^[Yy]$ ]]; then
  doIt
  fi
fi
unset doIt

